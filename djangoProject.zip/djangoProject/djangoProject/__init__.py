import pymysql

pymysql.install_as_MySQLdb()  #数据库初始化
